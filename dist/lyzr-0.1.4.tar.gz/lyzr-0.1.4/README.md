# lyzr

[![PyPI - Version](https://img.shields.io/pypi/v/lyzr-stack.svg)](https://pypi.org/project/lyzr-stack)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/lyzr-stack.svg)](https://pypi.org/project/lyzr-stack)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
cd dist/
pip install lyzr-[version]-py3-none-any.whl
```

## License

`lyzr` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
